## Instrucciones:

cmake CMakeLists.txt

make

#### Ejecutar con valores default
./tp1 archivo p

#### Ejecutar con epsilon determinado
./p1 archivo p -e n

donde n determina el exponente de (10^-n), que será tomado como epsilon

#### Ejecutar midiendo el tiempo de resolución
./p1 archivo p -t

## Link al informe:
https://www.overleaf.com/1935822621jmykxfdrbpxz
