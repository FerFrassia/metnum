#include <string>
#include <vector>

using namespace std;

namespace IO {
    void writeOutResult(const vector<double> &v, double p, string file);
    void writeTimeResult(double timeDiff, string file);
}

