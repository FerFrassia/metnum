
#include "iostream"
#include "test_create_matrix.h"

int main (){
    std::cout << "\nRunning create matrix tests\n";
    std::cout << "================================\n";
    RunAllTestsForCreateMatrix();

    return 0;
}