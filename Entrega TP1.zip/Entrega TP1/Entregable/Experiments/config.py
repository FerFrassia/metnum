p = 0.5
minNodes = 3
maxNodes = 1000
minP = 0
maxP = 1

cheaterGraphSize = 10
cheaterPage = int(cheaterGraphSize/2)
cheaterPageBudget = int(cheaterGraphSize*0.3)
cheaterLinkBudget = int(cheaterGraphSize*0.2)
repetitionsForCheaterTest = 1000
