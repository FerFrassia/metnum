import generateExperiments
import config as c
import runExperiments
import generateGraphs

generateExperiments.generarTests()
runExperiments.runTests()
generateGraphs.generateGraphs()
